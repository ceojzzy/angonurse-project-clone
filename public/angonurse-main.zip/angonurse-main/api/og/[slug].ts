import { supabase } from "@/integrations/supabase/client";

export default async function handler(req, res) {
  const { slug } = req.query;

  if (!slug) {
    return res.status(400).send("Slug is required");
  }

  try {
    // Busca o artigo no Supabase
    const { data: article, error } = await supabase
      .from("articles")
      .select("*")
      .eq("slug", slug)
      .eq("published", true)
      .single();

    if (error || !article) {
      return res.status(404).send("Article not found");
    }

    // Gera HTML OG dinamicamente
    const html = `
      <!DOCTYPE html>
      <html lang="pt">
      <head>
        <meta charset="UTF-8" />
        <title>${article.title_pt || article.title_en}</title>
        <meta property="og:title" content="${article.title_pt || article.title_en}" />
        <meta property="og:description" content="${article.excerpt_pt || article.content_pt?.substring(0, 160)}" />
        <meta property="og:image" content="${article.featured_image}" />
        <meta property="og:type" content="article" />
        <meta property="og:url" content="https://angonurse.vercel.app/artigo/${article.slug}" />
      </head>
      <body>
        <h1>${article.title_pt || article.title_en}</h1>
        <p>${article.excerpt_pt || article.content_pt?.substring(0, 160)}</p>
      </body>
      </html>
    `;

    res.setHeader("Content-Type", "text/html");
    res.send(html);
  } catch (err) {
    console.error(err);
    res.status(500).send("Internal Server Error");
  }
          }
